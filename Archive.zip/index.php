<?php 
    include('layout/app.php');
    include('component/home/banner.php');
    include('component/home/about.php');
    include('component/home/section3.php');
    include('component/home/ourproject.php');
    include('component/home/section5.php');
    include('component/home/stage.php');
    include('component/home/video.php');
    include('component/home/ourteam.php');
    include('component/home/count.php');
    include('component/home/testmonials.php');
    include('component/home/product.php');
    include('layout/footer.php');
?>
 



