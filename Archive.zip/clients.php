<?php 
   include('layout/app.php');
?>



    <!-- Carousel Start -->
    <div class="container-fluid p-0 margin_munus_top">
        <div id="header-carousel" class="carousel slide carousel-fade" data-ride="carousel" data-aos="fade-up">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="img/map.jpg" alt="Image">
                </div>

            </div>
        </div>
    </div>
    <!-- Carousel End -->
   <?php 
     include('component/client/client.php');
   ?>


    <?php
        include('layout/footer.php');
    ?>