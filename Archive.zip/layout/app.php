<?php 
include('config.php');
include('head.php');
include('modal.php');
include('navbar.php');


?>